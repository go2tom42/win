
function DeployMe {
    [cmdletbinding()]
    param
    (
    [string]$url = "/"
    )

    (New-Object System.Net.WebClient).DownloadFile($url,"$env:TEMP\part1.ps1");Start-Process -FilePath "powershell.exe" -ArgumentList "-File $env:TEMP\part1.ps1" -Verb RunAs
}

function Set-RunOnce {
    [cmdletbinding()]
    param
    (
    [string]$Command = '%systemroot%\System32\WindowsPowerShell\v1.0\powershell.exe -executionpolicy bypass -file c:\WORK\part3.ps1'
    )

    if (-not ((Get-Item -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce).'Run' ))
    {
        New-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce' -Name 'Run' -Value $Command -PropertyType ExpandString
    }
    else
    {
        Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce' -Name 'Run' -Value $Command -PropertyType ExpandString
    }
}
