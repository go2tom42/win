Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarSmallIcons" -Type DWord -Value 1
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People" -Name "PeopleBand" -Type DWord -Value 0
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "SearchboxTaskbarMode" -Type DWord -Value 0
New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarSizeMove" -Type DWord -Value 1
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarGlomLevel" -Type DWord -Value 2

Stop-Process -Name "Explorer"

Invoke-WebRequest "https://totalcommander.ch/win/tcmd1000x32_64.exe" -OutFile "c:\WORK\tcmd.exe"

Write-Output "Waiting 5 seconds"
Start-Sleep -s 5

start-process -FilePath "c:\WORK\tcmd.exe" -ArgumentList "/AHL0GDUKFW0" -Wait -WorkingDirectory "c:\WORK"
Set-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
Set-ItemProperty "HKLM:\SOFTWARE\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
Set-ItemProperty "HKCU:\SOFTWARE\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKLM:\SOFTWARE\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKCU:\SOFTWARE\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
Move-Item -Path "c:\WORK\wincmd.ini" -Destination "C:\Program Files\totalcmd\wincmd.ini" -Force

Get-CimInstance -Class Win32_UserProfile | Where-Object { $_.LocalPath.split('\')[-1] -eq 'IEUSER' } | Remove-CimInstance
Remove-LocalUser -Name "IEUSER"
net user "IEUSER" /delete


choco feature enable -n allowGlobalConfirmation

choco install 7zip.install GoogleChrome irfanview irfanview-shellextension irfanviewplugins notepadplusplus.install path-copy-copy putty.install windirstat winrar winscp.install firefox
Write-Output "Waiting 5 seconds"
Start-Sleep -s 5
Remove-Item -Path "C:\WORK" -Recurse -Force
Restart-Computer