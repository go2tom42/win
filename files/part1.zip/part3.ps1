
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarSmallIcons" -Type DWord -Value 1
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People" -Name "PeopleBand" -Type DWord -Value 0
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "SearchboxTaskbarMode" -Type DWord -Value 0
New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarSizeMove" -Type DWord -Value 1
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarGlomLevel" -Type DWord -Value 2

Stop-Process -Name "Explorer"

Invoke-WebRequest "https://totalcommander.ch/win/tcmd1000x32_64.exe" -OutFile "c:\WORK\tcmd.exe"
Invoke-WebRequest "https://github.com/go2tom42/win/raw/main/files/file1.bin" -OutFile "c:\WORK\wincmd.key"

Start-Sleep -s 5
start-process -FilePath "c:\WORK\tcmd.exe" -ArgumentList "/AHL0GDUKFW0 c:\totalcmd" -Wait -WorkingDirectory "c:\WORK"

start-process -FilePath "c:\WORK\tcmd.exe" -ArgumentList "/AHL0GDUKFW0" -Wait -WorkingDirectory "c:\WORK"

choco feature enable -n allowGlobalConfirmation


start-process -FilePath "$Env:Programfiles\totalcmd\tcunin64.exe" -ArgumentList "/7" -Wait -Passthru -NoNewWindow