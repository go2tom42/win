function Copy-Folder($Contents, $Destination) {
    $Contents = Get-ChildItem -Path $Contents
    foreach($Item in $Contents){
        Copy-Item -path $Item.FullName -Destination $Destination -Force -Recurse
        [int]$currentItem = [array]::indexof($Contents,$Item)
        Write-Progress -Activity "Moving files" -Status "Currently Moving - $($Item.Name) - File $($currentItem) of $($Contents.Count - 1) $([math]::round((($currentItem + 1)/$Contents.Count),2) * 100)% " -PercentComplete $([float](($currentItem + 1)/$Contents.Count) * 100)
        Start-Sleep -Seconds 1
    }    
}


$RestoreFolder = Get-Content -Path "~\restore.dir"

Invoke-WebRequest "https://totalcommander.ch/win/tcmd1000x32_64.exe" -OutFile "c:\WORK\tcmd.exe"
Invoke-WebRequest "https://www.binisoft.org/download/wfc6setup.exe" -OutFile "wfc6setup.exe"
Invoke-WebRequest "http://www.newsbin.com/download.php?reg=1&filename=nb682-full.exe&version=6.82" -OutFile "nb682-full.exe"

Write-Output "Waiting 5 seconds"
Start-Sleep -s 5

start-process -FilePath "c:\WORK\tcmd.exe" -ArgumentList "/AHL0GDUKFW0" -Wait -WorkingDirectory "c:\WORK"
Set-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
Set-ItemProperty "HKLM:\SOFTWARE\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
Set-ItemProperty "HKCU:\SOFTWARE\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKLM:\SOFTWARE\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKCU:\SOFTWARE\Ghisler\Total Commander" "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
Move-Item -Path "c:\WORK\wincmd.ini" -Destination "C:\Program Files\totalcmd\wincmd.ini" -Force
start-process -FilePath "wfc6setup.exe" -ArgumentList "-i -c" -Wait -WorkingDirectory "c:\WORK"
start-process -FilePath "nb682-full.exe" -ArgumentList "/S" -Wait -WorkingDirectory "c:\WORK"
start-process -FilePath "PinUtil.exe" -ArgumentList 'taskbar "C:\Program Files\totalcmd\TOTALCMD64.EXE"' -Wait -WorkingDirectory "c:\WORK"

If ($RestoreFolder -ne "NA") {

    if (Test-Path -Path "$RestoreFolder\appdata\Local") {
        Copy-Folder "$RestoreFolder\appdata\Local" "$Env:LOCALAPPDATA"
    }
    
    if (Test-Path -Path "$RestoreFolder\appdata\Roaming") {
        Copy-Folder "$RestoreFolder\appdata\Roaming" "$Env:APPDATA"
    }

    if (Test-Path -Path "$RestoreFolder\APPS\firefox") {
        Choco install firefox
        Copy-Folder "$RestoreFolder\APPS\firefox" "$Env:Programfiles\Mozilla Firefox"
        Start-Process -FilePath "c:\WORK\SetDefaultBrowser.exe" -ArgumentList "HKLM Firefox-308046B0AF4A39CB"
    } 

    if (Test-Path -Path "$RestoreFolder\Documents") {
        Copy-Folder "$RestoreFolder\Documents" ([Environment]::GetFolderPath("MyDocuments"))
    }
    
    if (Test-Path -Path "$RestoreFolder\Downloads") {
        Copy-Folder "$RestoreFolder\Downloads" ([Environment]::GetFolderPath('UserProfile') + "\Downloads")
    }
    
    if (Test-Path -Path "$RestoreFolder\EXTRAS\root") {
        Copy-Folder "$RestoreFolder\EXTRAS\root" "C:\"
    }
    
    if (Test-Path -Path "$RestoreFolder\EXTRAS\root\PATH") {
        $old = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name path).path
        $new = "$old;c:\PATH"
        Set-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name path -Value $new
    }
}

choco install shutup10 7zip.install adobereader atomicparsley calibre DotNet4.5.2 dotnetfx ffmpeg git.install github-desktop GoogleChrome handbrake.install hwinfo.install irfanview irfanview-shellextension irfanviewplugins jdownloader jre8 libreoffice-fresh makemkv mediainfo mkvtoolnix mp3tag MSVisualCplusplus2013-redist multipar.install notepadplusplus.install path-copy-copy picard putty.install python python3 steam teamviewer transgui typora visualstudio-installer visualstudio2019community vlc vscode.install win32diskimager.install windirstat winrar winscp.install youtube-dl
start-process -FilePath "OOSU10.exe" -ArgumentList "c:\WORK\ooshutup10.cfg /quiet" -Wait -WorkingDirectory "c:\WORK"

Write-Output "Waiting 5 seconds"
Start-Sleep -s 5

Restart-Computer



