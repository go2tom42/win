#function Copy-Folder($Contents, $Destination) {
#    $Contents = Get-ChildItem -Path $Contents
#    foreach($Item in $Contents){
#        Copy-Item -path $Item.FullName -Destination $Destination -Force -Recurse
#        [int]$currentItem = [array]::indexof($Contents,$Item)
#        Write-Progress -Activity "Moving files" -Status "Currently Moving - $($Item.Name) - File $($currentItem) of $($Contents.Count - 1) $([math]::round((($currentItem + 1)/$Contents.Count),2) * 100)% " -PercentComplete $([float](($currentItem + 1)/$Contents.Count) * 100)
#        Start-Sleep -Seconds 1
#    }    
#}

function Copy-Folder($sourcePath, $destinationPath) {

    $files = Get-ChildItem -Path $sourcePath -Recurse
    $filecount = $files.count
    $i=0
    Foreach ($file in $files) {
        $i++
        Write-Progress -activity "Moving files..." -status "($i of $filecount) $file" -percentcomplete (($i/$filecount)*100)
  
        # Determine the absolute path of this object's parent container.  This is stored as a different attribute on file and folder objects so we use an if block to cater for both
        if ($file.psiscontainer) {$sourcefilecontainer = $file.parent} else {$sourcefilecontainer = $file.directory}

        # Calculate the path of the parent folder relative to the source folder
        $relativepath = $sourcefilecontainer.fullname.SubString($sourcepath.length)

        # Copy the object to the appropriate folder within the destination folder
        copy-Item $file.fullname ($destinationPath + $relativepath) -Force
    }
}


$RestoreFolder = Get-Content -Path "~\restore.dir"

Invoke-WebRequest "https://totalcommander.ch/win/tcmd1000x32_64.exe" -OutFile "c:\WORK\tcmd.exe"
Invoke-WebRequest "https://www.binisoft.org/download/wfc6setup.exe" -OutFile "wfc6setup.exe"
Invoke-WebRequest "http://www.newsbin.com/download.php?reg=1&filename=nb682-full.exe&version=6.82" -OutFile "nb682-full.exe"
Invoke-WebRequest "https://github.com/microsoft/terminal/releases/download/v1.9.1942.0/Microsoft.WindowsTerminal_1.9.1942.0_8wekyb3d8bbwe.msixbundle" -OutFile "Microsoft.WindowsTerminal.msixbundle"
Write-Output "Waiting 5 seconds"
Start-Sleep -s 5

start-process -FilePath "c:\WORK\tcmd.exe" -ArgumentList "/AHL0GDUKFW0" -Wait -WorkingDirectory "c:\WORK"
Set-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Ghisler\Total Commander" -Name "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
Set-ItemProperty "HKLM:\SOFTWARE\Ghisler\Total Commander" -Name "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
Set-ItemProperty "HKCU:\SOFTWARE\Ghisler\Total Commander" -Name "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Ghisler\Total Commander" -Name "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKLM:\SOFTWARE\Ghisler\Total Commander" -Name "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKCU:\SOFTWARE\Ghisler\Total Commander" -Name "IniFileName" -Value ".\wincmd.ini" -type String -erroraction SilentlyContinue
New-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Feeds" -Name "ShellFeedsTaskbarViewMode" -PropertyType DWord -Value 3 -type String -erroraction SilentlyContinue
Set-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Feeds" -Name "ShellFeedsTaskbarViewMode" -PropertyType DWord -Value 3 -type String -erroraction SilentlyContinue


Move-Item -Path "c:\WORK\wincmd.ini" -Destination "C:\Program Files\totalcmd\wincmd.ini" -Force
start-process -FilePath "wfc6setup.exe" -ArgumentList "-i -c" -Wait -WorkingDirectory "c:\WORK"
start-process -FilePath "nb682-full.exe" -ArgumentList "/S" -Wait -WorkingDirectory "c:\WORK"
Add-AppxPackage "Microsoft.WindowsTerminal.msixbundle"
start-process -FilePath "PinUtil.exe" -ArgumentList 'taskbar "C:\Program Files\totalcmd\TOTALCMD64.EXE"' -Wait -WorkingDirectory "c:\WORK"

If ($RestoreFolder -ne "NA") {

    if (Test-Path -Path "$RestoreFolder\appdata\Local") {
        Copy-Folder "$RestoreFolder\appdata\Local" "$Env:LOCALAPPDATA"
    }
    
    if (Test-Path -Path "$RestoreFolder\appdata\Roaming") {
        Copy-Folder "$RestoreFolder\appdata\Roaming" "$Env:APPDATA"
    }

    if (Test-Path -Path "$RestoreFolder\APPS\firefox") {
        Choco install firefox
        Copy-Folder "$RestoreFolder\APPS\firefox" "$Env:Programfiles\Mozilla Firefox"
        Start-Process -FilePath "c:\WORK\SetDefaultBrowser.exe" -ArgumentList "HKLM Firefox-308046B0AF4A39CB"
    } 

    if (Test-Path -Path "$RestoreFolder\Documents") {
        Copy-Folder "$RestoreFolder\Documents" ([Environment]::GetFolderPath("MyDocuments"))
    }
    
    if (Test-Path -Path "$RestoreFolder\Downloads") {
        Copy-Folder "$RestoreFolder\Downloads" ([Environment]::GetFolderPath('UserProfile') + "\Downloads")
    }
    
    if (Test-Path -Path "$RestoreFolder\EXTRAS\root") {
        Copy-Folder "$RestoreFolder\EXTRAS\root" "C:\"
    }
    
    if (Test-Path -Path "$RestoreFolder\EXTRAS\root\PATH") {
        $old = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name path).path
        $new = "$old;c:\PATH"
        Set-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name path -Value $new
    }
}

choco install shutup10 7zip.install firefox adobereader atomicparsley calibre DotNet4.5.2 dotnetfx ffmpeg git.install powershell-core github-desktop GoogleChrome handbrake.install hwinfo.install irfanview irfanview-shellextension irfanviewplugins jdownloader jre8 libreoffice-fresh makemkv mediainfo mkvtoolnix mp3tag MSVisualCplusplus2013-redist multipar.install notepadplusplus.install path-copy-copy picard putty.install python python3 steam teamviewer transgui typora visualstudio-installer visualstudio2019community vlc vscode.install win32diskimager.install windirstat winrar winscp.install youtube-dl
start-process -FilePath "OOSU10.exe" -ArgumentList "c:\WORK\ooshutup10.cfg /quiet" -Wait -WorkingDirectory "c:\WORK"

Write-Output "Waiting 5 seconds"
Start-Sleep -s 5
Copy-Item -Path ".\LayoutExport.xml" -Destination "$env:LOCALAPPDATA\Microsoft\Windows\Shell\LayoutModification.xml" -Force
Get-ChildItem "HKCU:Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache\DefaultAccount" | Where Name -like "*tile*" | Remove-Item -Recurse -Force
Get-Process Explorer | Stop-Process
Restart-Computer



# Copy The Customized XML File to the correct Destination
Copy-Item -Path ".\LayoutExport.xml" -Destination "$env:LOCALAPPDATA\Microsoft\Windows\Shell\LayoutModification.xml" -Force

# Delete Every Registry Key in the Cache including "tiles"
Get-ChildItem "HKCU:Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache\DefaultAccount"|
    Where Name -like "*tile*"|
        Remove-Item -Recurse -Force

# Restart Explorer.exe
